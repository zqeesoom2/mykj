<?php
return [
    'weixin'=>['token'=>'zm530195656','appid'=>'wx3ac716f067f03c19','appsecret'=>'15b4a123345314f805a4546ca6ff0016'],
    'beanstalkd'=>[
       // 'host'=> '192.168.0.107'
          'host'=> '192.168.71.128'
    ],
    'mysql'=>['ip'=>'172.100.100.91','username'=>'root','password'=>'000000','dbname'=>'mykj'],

];


