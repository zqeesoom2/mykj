<?php
$config =  [
         'driver'=> 'mysql',
         'host'=> '172.100.100.91',
         'database' => 'mykj',
         'username' => 'root',
         'password' => '000000',
         'charset' => 'gbk',
         'collation' => 'gbk-chinese_ci',
         'prefix'=>'pre',
         'strict'=>false,
         'engine'=>null
];