#!/bin/sh
cloc . --exclude-dir=thirdparty,Debug,CMakeFiles,build,CMakeFiles,.git
